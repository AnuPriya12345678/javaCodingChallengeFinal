package com.java.codingChallenge.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.codingChallenge.dao.ProductDao;
import com.java.codingChallenge.dao.ProductsDaoImpl;
import com.java.codingChallenge.model.Products;

public class ShowProductsMain {

	public static void main(String[] args) {
		
		ProductDao p = new ProductsDaoImpl();
		List<Products> productsList;
		try {
			productsList = p.ShowProducts();
			for(Products product : productsList)
				System.out.println(product);

		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

}
