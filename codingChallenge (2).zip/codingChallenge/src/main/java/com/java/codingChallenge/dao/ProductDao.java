package com.java.codingChallenge.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.codingChallenge.model.Products;

public interface ProductDao {
	
	List<Products> ShowProducts() throws ClassNotFoundException, SQLException;
    Products SearchByProductId(int productId) throws ClassNotFoundException, SQLException;
	
}
