package com.java.codingChallenge.util;

import java.util.ResourceBundle;

public class DBPropertyUtil {
	
	public static String getConnectionString(String propertyFileName) {
		ResourceBundle rb = ResourceBundle.getBundle(propertyFileName);
		String connectionString = rb.getString("url");
		return connectionString;
	}

}
