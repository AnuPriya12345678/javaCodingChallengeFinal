package com.java.codingChallenge.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.codingChallenge.dao.OrderDao;
import com.java.codingChallenge.dao.OrderDaoImpl;
import com.java.codingChallenge.model.OrderItems;
import com.java.codingChallenge.model.Orders;

public class ShowCustomerOrdersMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter customer id : ");
		int customerId = sc.nextInt();
		OrderDao o = new OrderDaoImpl();
		try {
			List<OrderItems> orderList = o.ShowCustomerOrders(customerId);
			for(OrderItems order : orderList)
				System.out.println(order);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

}
