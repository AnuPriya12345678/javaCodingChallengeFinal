package com.java.codingChallenge.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.codingChallenge.dao.CustomerDao;
import com.java.codingChallenge.dao.CustomerDaoImpl;

public class AuthenticateCustomerMain {

	public static void main(String[] args) {
		
		String firstName, lastName, password;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Firt Name : ");
		firstName = sc.next();
		System.out.println("Enter Last Name : ");
		lastName = sc.next();
		System.out.println("Enter Password   ");
		password = sc.next();
		CustomerDao c = new CustomerDaoImpl();
		int count;
		try {
				count = c.authenticateCustomer(firstName, lastName, password);
				if (count==1) {
					System.out.println("Correct Credentials...");
				} 
				else {
					System.out.println("Invalid Credentials...");
				}
			
			} 
		catch (ClassNotFoundException | SQLException e){
				e.printStackTrace();
			}
			
		
	}

}
