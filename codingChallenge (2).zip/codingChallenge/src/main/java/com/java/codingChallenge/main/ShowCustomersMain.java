package com.java.codingChallenge.main;

import java.sql.SQLException;
import java.util.List;

import com.java.codingChallenge.dao.CustomerDao;
import com.java.codingChallenge.dao.CustomerDaoImpl;
import com.java.codingChallenge.model.Customers;

public class ShowCustomersMain {
	
	public static void main(String[] args)
	{
		CustomerDao c = new CustomerDaoImpl();
		try {
			List<Customers> customerList = c.ShowCustomers();
			for(Customers customer : customerList)
				System.out.println(customer);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

}
