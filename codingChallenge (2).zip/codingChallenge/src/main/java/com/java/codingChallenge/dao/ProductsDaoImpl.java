package com.java.codingChallenge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.codingChallenge.model.Products;
import com.java.codingChallenge.util.DBConnUtil;
import com.java.codingChallenge.util.DBPropertyUtil;


public class ProductsDaoImpl implements ProductDao {
	
	Connection con;
	PreparedStatement pst;

	@Override
	public List<Products> ShowProducts() throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectionString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM products";
		pst = con.prepareStatement(query);
		ResultSet rs = pst.executeQuery();
		List<Products> productList = new ArrayList<Products> ();
		Products product = null;
		while(rs.next())
		{
			product = new Products();
			product.setProductId(rs.getInt("productId"));
			product.setName(rs.getString("name"));
			product.setDescription(rs.getString("description"));
			product.setPrice(rs.getDouble("price"));
			product.setStockQuantity(rs.getInt("stockQuantity"));
			productList.add(product);
		}
		return productList;
		
	}

	@Override
	public Products SearchByProductId(int productId) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectionString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM products WHERE productId = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, productId);
		ResultSet rs = pst.executeQuery();
		Products product = null;
		if(rs.next())
		{
			product = new Products();
			product.setProductId(rs.getInt("productId"));
			product.setName(rs.getString("name"));
			product.setDescription(rs.getString("description"));
			product.setPrice(rs.getDouble("price"));
			product.setStockQuantity(rs.getInt("stockQuantity"));
		}
		return product;
		
	}
	
	

}
