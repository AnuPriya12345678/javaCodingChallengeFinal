package com.java.codingChallenge.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.codingChallenge.model.OrderItems;
import com.java.codingChallenge.model.Orders;

public interface OrderDao {
	
	List<OrderItems> ShowCustomerOrders(int customerId) throws ClassNotFoundException, SQLException;
	String PlaceOrder(int customerID, int productId, int quantity) throws ClassNotFoundException, SQLException;

}
