package com.java.codingChallenge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.codingChallenge.model.Customers;
import com.java.codingChallenge.model.Products;
import com.java.codingChallenge.util.DBConnUtil;
import com.java.codingChallenge.util.DBPropertyUtil;

public class CustomerDaoImpl implements CustomerDao {
	
	Connection con;
	PreparedStatement pst;

	@Override
	public List<Customers> ShowCustomers() throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectionString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM customers";
		pst = con.prepareStatement(query);
		ResultSet rs = pst.executeQuery();
		List<Customers> customerList = new ArrayList<Customers> ();
		Customers customer = null;
		while(rs.next())
		{
			customer = new Customers();
			customer.setCustomerId(rs.getInt("customerId"));
			customer.setFirstName(rs.getString("firstName"));
			customer.setLastName(rs.getString("lastName"));
			customer.setEmail(rs.getString("email"));
			customer.setPassword(rs.getString("password"));
			customer.setAddress(rs.getString("address"));
			customerList.add(customer);
		}
		return customerList;
		
	}

	@Override
	public Customers SearchByCustomerId(int customerID) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectionString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM customers WHERE customerId = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, customerID);
		ResultSet rs = pst.executeQuery();
		Customers customer = null;
		if(rs.next())
		{
			customer = new Customers();
			customer.setCustomerId(rs.getInt("customerId"));
			customer.setFirstName(rs.getString("firstName"));
			customer.setLastName(rs.getString("lastName"));
			customer.setEmail(rs.getString("email"));
			customer.setPassword(rs.getString("password"));
			customer.setAddress(rs.getString("address"));
		}
		return customer;
		
	}

	@Override
	public Customers SearchByEmail(String email) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectionString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM customers WHERE email = ?";
		pst = con.prepareStatement(query);
		pst.setString(1, email);
		ResultSet rs = pst.executeQuery();
		Customers customer = null;
		if(rs.next())
		{
			customer = new Customers();
			customer.setCustomerId(rs.getInt("customerId"));
			customer.setFirstName(rs.getString("firstName"));
			customer.setLastName(rs.getString("lastName"));
			customer.setEmail(rs.getString("email"));
			customer.setPassword(rs.getString("password"));
			customer.setAddress(rs.getString("address"));
		}
		return customer;
		
	}

	@Override
	public int AuthenticateCustomer(String firstName, String lastName, String password) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectionString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT count(*) AS COUNT FROM customers WHERE firstName = ? AND lastName = ? AND password = ?";
		pst = con.prepareStatement(query);
		pst.setString(1, firstName);
		pst.setString(2, lastName);
		pst.setString(3, password);
		ResultSet rs = pst.executeQuery();
		rs.next();
		return rs.getInt("count");
		
	}

	@Override
	public String AddCustomer(Customers customer) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectionString("db");
		con = DBConnUtil.getConnection(connectionString);
		String pwd = EncryptPassword.getCode(customer.getPassword());
		customer.setPassword(pwd);
		String query = "INSERT INTO customers VALUES(?,?,?,?,?,?)";
		pst = con.prepareStatement(query);
		pst.setInt(1, customer.getCustomerId());
		pst.setString(2, customer.getFirstName());
		pst.setString(3, customer.getLastName());
		pst.setString(4, customer.getEmail());
		pst.setString(5, customer.getPassword());
		pst.setString(6, customer.getAddress());
		pst.executeUpdate();
		return "Customer Added ...";
		
	}

	
	
}
